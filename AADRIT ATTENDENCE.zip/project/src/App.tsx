import React, { useState, useEffect } from 'react';
import { Calculator, Calendar, CheckCircle, XCircle, BarChart, Bell, History, Download, PieChart } from 'lucide-react';

interface AttendanceRecord {
  date: string;
  attended: boolean;
}

interface WeeklyStats {
  week: number;
  attended: number;
  total: number;
}

function App() {
  const [totalClasses, setTotalClasses] = useState<number>(0);
  const [attendedClasses, setAttendedClasses] = useState<number>(0);
  const [targetPercentage, setTargetPercentage] = useState<number>(75);
  const [alertThreshold, setAlertThreshold] = useState<number>(80);
  const [attendanceHistory, setAttendanceHistory] = useState<AttendanceRecord[]>([]);
  const [showAlert, setShowAlert] = useState<boolean>(false);

  // Calculate current attendance percentage
  const currentPercentage = totalClasses === 0 
    ? 0 
    : (attendedClasses / totalClasses) * 100;

  // Calculate classes needed to reach target
  const calculateClassesNeeded = () => {
    if (currentPercentage >= targetPercentage) {
      return 0;
    }
    
    const x = Math.ceil((targetPercentage * totalClasses - 100 * attendedClasses) / (100 - targetPercentage));
    return x < 0 ? 0 : x;
  };

  // Calculate if it's possible to reach target
  const isPossibleToReachTarget = () => {
    if (currentPercentage >= targetPercentage) return true;
    const maxPossiblePercentage = (attendedClasses / totalClasses) * 100;
    return maxPossiblePercentage >= targetPercentage;
  };

  // Add attendance record
  const addAttendanceRecord = (attended: boolean) => {
    const newRecord: AttendanceRecord = {
      date: new Date().toISOString().split('T')[0],
      attended
    };
    setAttendanceHistory(prev => [...prev, newRecord]);
    setTotalClasses(prev => prev + 1);
    if (attended) {
      setAttendedClasses(prev => prev + 1);
    }
  };

  // Calculate weekly statistics
  const calculateWeeklyStats = (): WeeklyStats[] => {
    const stats: { [key: number]: WeeklyStats } = {};
    
    attendanceHistory.forEach(record => {
      const date = new Date(record.date);
      const weekNumber = Math.ceil((date.getDate()) / 7);
      
      if (!stats[weekNumber]) {
        stats[weekNumber] = { week: weekNumber, attended: 0, total: 0 };
      }
      
      stats[weekNumber].total += 1;
      if (record.attended) {
        stats[weekNumber].attended += 1;
      }
    });

    return Object.values(stats);
  };

  // Export attendance data
  const exportData = () => {
    const data = {
      totalClasses,
      attendedClasses,
      currentPercentage,
      targetPercentage,
      history: attendanceHistory
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'attendance-data.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Check attendance alert
  useEffect(() => {
    if (currentPercentage < alertThreshold) {
      setShowAlert(true);
    } else {
      setShowAlert(false);
    }
  }, [currentPercentage, alertThreshold]);

  const classesNeeded = calculateClassesNeeded();
  const weeklyStats = calculateWeeklyStats();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-indigo-900 flex items-center justify-center gap-2">
              <Calculator className="w-8 h-8" />
              College Attendance Calculator
            </h1>
            <p className="text-gray-600 mt-2">Track and plan your attendance to meet college requirements</p>
          </div>

          {showAlert && (
            <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Warning: Your attendance is below the alert threshold of {alertThreshold}%
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="space-y-4">
                <label className="block">
                  <span className="text-gray-700">Total Classes Conducted</span>
                  <input
                    type="number"
                    min="0"
                    value={totalClasses}
                    onChange={(e) => setTotalClasses(Math.max(0, parseInt(e.target.value) || 0))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </label>

                <label className="block">
                  <span className="text-gray-700">Classes Attended</span>
                  <input
                    type="number"
                    min="0"
                    max={totalClasses}
                    value={attendedClasses}
                    onChange={(e) => setAttendedClasses(Math.min(totalClasses, Math.max(0, parseInt(e.target.value) || 0)))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </label>

                <label className="block">
                  <span className="text-gray-700">Target Attendance (%)</span>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={targetPercentage}
                    onChange={(e) => setTargetPercentage(Math.min(100, Math.max(0, parseInt(e.target.value) || 0)))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </label>

                <label className="block">
                  <span className="text-gray-700">Alert Threshold (%)</span>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={alertThreshold}
                    onChange={(e) => setAlertThreshold(Math.min(100, Math.max(0, parseInt(e.target.value) || 0)))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  />
                </label>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <BarChart className="w-5 h-5" />
                Statistics
              </h2>
              <div className="space-y-4">
                <div>
                  <p className="text-gray-600">Current Attendance</p>
                  <p className="text-2xl font-bold text-indigo-600">
                    {currentPercentage.toFixed(2)}%
                  </p>
                </div>
                
                <div>
                  <p className="text-gray-600">Target Status</p>
                  <div className="flex items-center gap-2">
                    {currentPercentage >= targetPercentage ? (
                      <>
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span className="text-green-500 font-medium">Target Achieved!</span>
                      </>
                    ) : isPossibleToReachTarget() ? (
                      <>
                        <Calendar className="w-5 h-5 text-yellow-500" />
                        <span className="text-yellow-500 font-medium">Need to attend {classesNeeded} more classes</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-5 h-5 text-red-500" />
                        <span className="text-red-500 font-medium">Target not achievable</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <History className="w-5 h-5" />
                Quick Actions
              </h2>
              <div className="space-y-4">
                <div className="flex gap-2">
                  <button
                    onClick={() => addAttendanceRecord(true)}
                    className="flex-1 bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition-colors"
                  >
                    Mark Present
                  </button>
                  <button
                    onClick={() => addAttendanceRecord(false)}
                    className="flex-1 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition-colors"
                  >
                    Mark Absent
                  </button>
                </div>
                <button
                  onClick={exportData}
                  className="w-full flex items-center justify-center gap-2 bg-indigo-500 text-white px-4 py-2 rounded hover:bg-indigo-600 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Export Data
                </button>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <PieChart className="w-5 h-5" />
                Weekly Breakdown
              </h2>
              <div className="space-y-2">
                {weeklyStats.map((stat) => (
                  <div key={stat.week} className="flex items-center justify-between">
                    <span className="text-gray-600">Week {stat.week}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-indigo-600 font-medium">
                        {stat.attended}/{stat.total}
                      </span>
                      <span className="text-gray-500">
                        ({((stat.attended / stat.total) * 100).toFixed(1)}%)
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Tips & Recommendations</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Try to maintain attendance above target percentage to have a safety buffer</li>
              <li>Keep track of your attendance regularly to avoid last-minute issues</li>
              <li>If you miss classes, inform your professors and get the missed content</li>
              <li>Consider medical certificates and other valid reasons for attendance consideration</li>
              <li>Set your alert threshold higher than your target to get early warnings</li>
              <li>Review your weekly attendance patterns to identify and address any concerning trends</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;